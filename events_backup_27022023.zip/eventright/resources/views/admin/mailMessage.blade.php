<div class="mailMessage">
    {!!$content!!}
</div>   
